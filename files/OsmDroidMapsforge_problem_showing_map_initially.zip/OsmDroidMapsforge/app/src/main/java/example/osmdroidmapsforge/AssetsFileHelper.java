package example.osmdroidmapsforge;

import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import org.osmdroid.config.Configuration;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * This class provides essentially three methods (and some additional helper methods) for mapsforge files ( .map files):
 *  - retrieving map files (as inpuot streams) from an assets folder in the project directory
 *  - copying those input streams to .map files in the external storage
 *  - retrieving those .map files from the external storage
 */
public final class AssetsFileHelper {

    private final static String LOG_TAG = AssetsFileHelper.class.getName();
    private final static String NAME_OF_ASSETS_SUB_DIRECTORY_WITH_MAPSFORGE_MAPS = "mapsforge_maps_assets";

    private final AppCompatActivity activity;

    public AssetsFileHelper(AppCompatActivity activity) {
        this.activity = activity;
    }

    public void copyAssetMapsInputStreamsToOsmDroidDirectoryIfNotAlreadyExisting() {
        showMessage("copyAssetMapsInputStreamsToOsmDroidDirectoryIfNotAlreadyExisting starts");
        if(areAllMapsInAssetsFolderExistingInOsmDroidFolder()) {
            showMessage("no new files (i.e. files not currently located in osmdroid folder) in the assets folder.");
        }
        else {
            showMessage("missing files should now be copied from assets folder");
            showMessage("before the deletion of existing map files");
            final List<NameAndStream> allAssetsWithMapsforgeMapsAsInputStreams = getAllAssetsWithMapsforgeMapsAsInputStreams();
            final File[] mapsforgeFiles = getAllMapsforgeFilesInOsmDroidDirectory();
            final Set<String> namesOfMapFilesInAssetsFolder = getNamesOfMapsInAssetFolder();
            for(File f : mapsforgeFiles) {
                if(namesOfMapFilesInAssetsFolder.contains(f.getName()) && f.exists()) {
                    showMessage("deleting the file " + f.getAbsolutePath());
                    f.delete();
                }
            }
            final File osmDroidDirectory = getOsmdroidDirectoryWithMapsforgeFiles();
            for ( NameAndStream nameAndStream : allAssetsWithMapsforgeMapsAsInputStreams) {
                File mapFileToCreate = new File(osmDroidDirectory, nameAndStream.mapName);
                this.copyInputStreamToFile(nameAndStream.mapStream, mapFileToCreate);
                showMessage("now the map is copied: " + nameAndStream.mapName);
            }
            showMessage("after copying all maps");
            final File[] mapfiles = getAllMapsforgeFilesInOsmDroidDirectory();
            showMessage("copyAssetMapsInputStreamsToOsmDroidDirectoryIfNotAlreadyExisting ends: the number of map files: " + mapfiles.length);
        }
    }

    // final List<NameAndStream> allAssetsWithMapsforgeMapsAsInputStreams = getAllAssetsWithMapsforgeMapsAsInputStreams();

    private Set<String> getNamesOfMapsInAssetFolder() {
        List<NameAndStream> allAssetsWithMapsforgeMapsAsInputStreams = getAllAssetsWithMapsforgeMapsAsInputStreams(true); // true = close the stream
        // can not implement with Java 8 (Android API 24) streams here since targeting Android API 19
        Set<String> mapFileAssetsNames = new HashSet<String>();
        for (NameAndStream nameAndStream: allAssetsWithMapsforgeMapsAsInputStreams) {
            mapFileAssetsNames.add(nameAndStream.mapName);
        }
        return mapFileAssetsNames;
    }

    private Set<String> getNamesOfMapFilesInOsmDroidDirectory() {
        final File[] mapsforgeFiles = getAllMapsforgeFilesInOsmDroidDirectory();
        // can not implement with Java 8 (Android API 24) streams here since targeting Android API 19
        Set<String> fileNames  = new HashSet<String>();
        for (File file: mapsforgeFiles) {
            fileNames.add(file.getName());
        }
        return fileNames;
    }

    private boolean areAllMapsInAssetsFolderExistingInOsmDroidFolder() {
        Set<String> namesOfMapFilesInAssetsFolder = getNamesOfMapsInAssetFolder();
        Set<String> namesOfMapFilesInOsmDroidDirectory = getNamesOfMapFilesInOsmDroidDirectory();
        for (String inputStreamName: namesOfMapFilesInAssetsFolder) {
            if(!namesOfMapFilesInOsmDroidDirectory.contains(inputStreamName)) {
                showMessage("Difference detected assets folder input stream map : " + inputStreamName + " does not exist in osm directory");
                return false;
            }
        }
        return true;
    }


    private List<NameAndStream> getAllAssetsWithMapsforgeMapsAsInputStreams() {
        return getAllAssetsWithMapsforgeMapsAsInputStreams(false);
    }
    /**
     * @param closeStreamImmediately true when the stream will not be used but the method is reused just for retrieving the names
     * @return
     */
    private List<NameAndStream> getAllAssetsWithMapsforgeMapsAsInputStreams(boolean closeStreamImmediately) {
        showMessage("getAllAssetsWithMapsforgeMapsAsInputStreams method starts");
        final List<NameAndStream> list = new ArrayList<NameAndStream>();
        final AssetManager assetManager = activity.getAssets();
        try {
            final String[] mapFileNames = assetManager.list(NAME_OF_ASSETS_SUB_DIRECTORY_WITH_MAPSFORGE_MAPS);
            for(String mapFileName : mapFileNames) {
                if(!mapFileName.endsWith(".map")) continue;
                InputStream mapsforgeMapAsInputStream = assetManager.open(NAME_OF_ASSETS_SUB_DIRECTORY_WITH_MAPSFORGE_MAPS + "/" + mapFileName);
                list.add(new NameAndStream(mapFileName, mapsforgeMapAsInputStream) );
                if(closeStreamImmediately) mapsforgeMapAsInputStream.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
            showMessage("PROBLEM in the method getAllAssetsWithMapsforgeMapsAsInputStreams: " + e.getMessage());
        }
        if(list.size() == 0) {
            showErrorMessage("No assets with mapsforge .map files could be retrieved from assets subdirectory i.e. the directory /app/src/main/assets/" + NAME_OF_ASSETS_SUB_DIRECTORY_WITH_MAPSFORGE_MAPS);
        }
        showMessage("getAllAssetsWithMapsforgeMapsAsInputStreams method ends");
        return list;
    }


    private void copyInputStreamToFile(InputStream inputStreamSource, File targetFile) {
        OutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(targetFile);
            byte[] buffer = new byte[1024];
            int len;
            while ((len = inputStreamSource.read(buffer)) != -1) {
                outputStream.write(buffer, 0, len);
            }
            outputStream.close();
            inputStreamSource.close();
            showMessage("copyInputStreamToFile method finished without exception");
        } catch (Exception e) {
            showMessage("copyInputStreamToFile method finished WITH exception: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private File getOsmdroidDirectoryWithMapsforgeFiles() {
        final File osmDroidDirectory = Configuration.getInstance().getOsmdroidBasePath(); // https://github.com/osmdroid/osmdroid/wiki/Offline-Map-Tiles
        showMessage("path to osmdroid directory " + osmDroidDirectory.getAbsolutePath());
        showMessage("osmdroid directory exists ? bool value:  " + osmDroidDirectory.exists());
        if(!osmDroidDirectory.exists()) {
            boolean result = osmDroidDirectory.mkdirs();
            showMessage("osmdroid directory result after having tried to create it ? bool value: " + result);
        }
        showMessage("osmdroid directory exists ? bool value:  " + osmDroidDirectory.exists());
        if(!osmDroidDirectory.exists()) {
            showErrorMessage("osmdroid directory still does not exist");
        }
        return osmDroidDirectory;
    }

    public File[] getAllMapsforgeFilesInOsmDroidDirectory() {
        showMessage("method getAllMapsforgeFilesInOsmDroidDirectory starts");
        final File osmDroidDirectory = getOsmdroidDirectoryWithMapsforgeFiles();
        if(!osmDroidDirectory.exists() || !osmDroidDirectory.isDirectory()) {
            showMessage("method getAllMapsforgeFilesInOsmDroidDirectory ends because of no osmdroid directory");
            return new File[]{};
        }
        final File[] files = osmDroidDirectory.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File directory, String filename) {
                showMessage("file in osmdroid directory: " + filename);
                return filename.endsWith(".map");
            }
        });
        showMessage("method getAllMapsforgeFilesInOsmDroidDirectory ends with this number of found files:  " + files.length);
        if(files.length == 0) {
            showErrorMessage("method getAllMapsforgeFilesInOsmDroidDirectory ends. No map files could be retrieved");
        }
        return files;
    }

    private void showErrorMessage(String message) {
        Log.e(LOG_TAG, message);
        Toast.makeText(this.activity, message, Toast.LENGTH_LONG).show();
    }

    private void showMessage(String message) {
        Log.d(LOG_TAG, message);
        // Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private class NameAndStream {
        final String mapName;
        final InputStream mapStream;
        NameAndStream(String mapName, InputStream mapStream) {
            this.mapName = mapName;
            this.mapStream = mapStream;
        }
    }
}