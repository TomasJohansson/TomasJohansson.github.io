package example.osmdroidmapsforge;

// The osmdroid/Mapsforge code in this class is based on code found at these pages:
//  https://github.com/osmdroid/osmdroid/wiki/How-to-use-the-osmdroid-library
//  https://github.com/osmdroid/osmdroid/wiki/Mapsforge
//  https://github.com/osmdroid/osmdroid/blob/fe223f1c2afbc12fe4c05096858c3bf221660575/OpenStreetMapViewer/src/main/java/org/osmdroid/samplefragments/tileproviders/MapsforgeTileProviderSample.java

// I have tested this app with two tablets (Android 4.4 and 7.1)
// and the behaviour is the same, i.e. to initialize the map I can either
// click the button or invoked the delay method at the very bottom of this class,
// but do not know how to initialize the map automatically without such a workaround method?

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import org.osmdroid.config.Configuration;
import org.osmdroid.views.MapView;
import org.mapsforge.map.rendertheme.XmlRenderTheme;
import org.osmdroid.mapsforge.MapsForgeTileProvider;
import org.osmdroid.mapsforge.MapsForgeTileSource;
import org.osmdroid.tileprovider.util.SimpleRegisterReceiver;
import java.io.File;

public class MainActivity extends AppCompatActivity {
    private final static String LOG_TAG = MainActivity.class.getName();
    private final static int MY_PERMISSIONS_WRITE_EXTERNAL_STORAGE = 1;

    private MapView mMapView = null;
    private AssetsFileHelper assetsFileHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        assetsFileHelper = new AssetsFileHelper(this);

        if(hasPemissionToWriteExternalStorage()) {
            initializeOfflineMap();
        }
        else {
            showErrorMessage("WRITE_EXTERNAL_STORAGE permission is needed");
            requestPemissionToWriteExternalStorage();
        }
    }

    private void initializeOfflineMap() {
        assetsFileHelper.copyAssetMapsInputStreamsToOsmDroidDirectoryIfNotAlreadyExisting();

        Context ctx = getApplicationContext();
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx));

        setContentView(R.layout.activity_main);
        mMapView = (MapView) findViewById(R.id.map);
        final Button buttonForOsmDroidMapsforge = (Button) findViewById(R.id.buttonForOsmDroidMapsforge);
        buttonForOsmDroidMapsforge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showOfflineMaps();
            }
        });

        MapsForgeTileSource.createInstance(this.getApplication());

        showOfflineMaps();
        //      The above "showOfflineMaps" does NOT cause the maps to become shown
        //      But when "showOfflineMaps" is invoked from the button click, then the maps becomes displayed
        //  Another alternative (which works for some reason): invoke the below method (currently disabled)
        // showMapsforgeMapsDelayed();
        //      The above method will also invoke "showOfflineMaps" but from a separate thread after a small delay
    }

    private void showOfflineMaps() {
        final File[] maps = assetsFileHelper.getAllMapsforgeFilesInOsmDroidDirectory();
        if(maps.length == 0) {
            showErrorMessage("No map files can be shown");
            return;
        }

        XmlRenderTheme theme = null; //null is ok here, uses the default rendering theme if it's not set
        MapsForgeTileSource fromFiles = MapsForgeTileSource.createFromFiles(maps, theme, "rendertheme-v4");
        MapsForgeTileProvider forge = new MapsForgeTileProvider(
                new SimpleRegisterReceiver(getApplicationContext()),
                fromFiles, null);

        mMapView.setTileProvider(forge);

        mMapView.getController().setZoom(fromFiles.getMinimumZoomLevel());
        mMapView.zoomToBoundingBox(fromFiles.getBoundsOsmdroid(), true);
    }

    public void onResume(){
        // onResume is invoked later than onCreate and onStart but using "showOfflineMaps" from below is NOT a working alternative
        // to using the method "showMapsforgeMapsDelayed"  (invoking "showOfflineMaps" from another thread).
        super.onResume();
        //showOfflineMaps(); // does NOT help i.e. dows not cause the maps to become shown initially
        if(this.mMapView != null) {
            this.mMapView.onPause();  //needed for compass, my location overlays, v6.0.0 and up
            //showOfflineMaps(); // does NOT help i.e. dows not cause the maps to become shown initially
        }
    }

    public void onPause(){
        super.onPause();
        if(this.mMapView != null) {
            this.mMapView.onPause();  //needed for compass, my location overlays, v6.0.0 and up
        }
    }

    // ------------------------------------------------------------------------------------------------------------------------------
    // Three methods related to permissions to write to the Android "external storage":
    private void requestPemissionToWriteExternalStorage() {
        // https://developer.android.com/training/permissions/requesting
        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                MY_PERMISSIONS_WRITE_EXTERNAL_STORAGE
        );
    }
    private boolean hasPemissionToWriteExternalStorage() {
        // https://developer.android.com/training/permissions/requesting
        return ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED;
    }
    @Override // https://developer.android.com/training/permissions/requesting
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if(requestCode == MY_PERMISSIONS_WRITE_EXTERNAL_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initializeOfflineMap();
            }
            else {
                showErrorMessage("WRITE_EXTERNAL_STORAGE: Permission denied");
            }
        }
    }
    // ------------------------------------------------------------------------------------------------------------------------------
    // two Log/Toast methods
    private void showMessage(String message) {
        Log.d(LOG_TAG, message);
        // Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
    private void showErrorMessage(String message) {
        Log.e(LOG_TAG, message);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
    // ------------------------------------------------------------------------------------------------------------------------------


    // If the method below is invoked from "initializeOfflineMap" (which is invoked from "onCreate")
    // then the map becomes initially shown, but why ?
    // But the most important question is how to make the offline maps become displayed
    // initially without having to use this kind of ugly workaround???

    private boolean hasBeenDelayedOnce = false;
    private void showMapsforgeMapsDelayed() {
        if(hasBeenDelayedOnce) {
            showMessage("no more delay , only the first time");
            return;
        }
        showMessage("will delay , now is the first time");
        final int milliseconds = 100; // 100 milliseconds seems to be enough for the maps to become displayed without having to click the buttno
        final FragmentActivity act = this;
        final Thread thread = new Thread(new Runnable() {
            public void run() {
                try {
                    Thread.sleep(milliseconds);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                act.runOnUiThread(new Runnable(){
                    @Override
                    public void run() {
                        Toast.makeText(act, "will now invoke showOfflineMaps from a thread", Toast.LENGTH_LONG).show();
                        showOfflineMaps();
                    }
                });
            }
        });
        // if the thread object is just instantiated, then world map becomes shown ... ?
        // but if it the thread is also started as below then it actually zooms in properly at the bounding box of the maps
        thread.start();
        hasBeenDelayedOnce = true;
    }
}